﻿Public Class Form1
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Dim parallelQuery = From num As C1.Win.C1Input.DropDownItem In C1SplitButton1.Items.AsParallel
        '                    Where num.Checked = True
        '                    Select num

        'parallelQuery.ForAll(Sub(i)
        '                         MessageBox.Show(String.Format("C1SpliteButton1 Item Checked:{0}", i.Text))
        '                     End Sub)

        MessageBox.Show("登録しました。")
        btnClose.PerformClick()

    End Sub

    Private Sub btnSave_DropDownItemClicked(sender As Object, e As C1.Win.C1Input.DropDownItemClickedEventArgs) Handles btnSave.DropDownItemClicked
        'With e.ClickedItem
        '    Dim parallelQuery = From num As C1.Win.C1Input.DropDownItem In .SplitButton.Items.AsParallel
        '                        Where Not num.Text = .Text
        '                        Select num

        '    parallelQuery.ForAll(Sub(i)
        '                             i.Checked = False
        '                         End Sub)
        'End With
        'MessageBox.Show(String.Format("C1SpliteButton1 Item Clicked:{0}", e.ClickedItem.Text))
        Dim subForm As New SubForm
        subForm.Show()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub
End Class
